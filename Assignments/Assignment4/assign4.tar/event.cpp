/********************************************************
 * Program Name: wumpus.cpp
 * Author: Joseph Murche
 * Date: May 21st, 2021
 * Description: play as an adventurer on a quest to get the gold from the wumpus cave.
 * Input: integers.
 * Output: integers and strings.
 *********************************************************/

#include "event.h"
#include <iostream>

using namespace std;

event::event(){

}

void event::encounter(){

}

void event::percept(){

}