/************************************************
 * Program Name: Zoo Tycoon
 * Author: Joseph Murche
 * Date: 2/2/21
 * Input:int
 * Output:strings,int
 * ***********************************************/
#include <iostream>
#include <cstdlib>
#include <cstring>

#ifndef ZOO_H
#define ZOO_H

#include "animal.h"
#include "Tiger.h"
#include "Sealion.h"
#include "blackbear.h"

class Zoo
{
   private:
      int money;
      int choice;
      int tigerSize;
      int sealionSize;
      int blackbearSize;
      Tigers** tigers;
      Sealions** sealions;
      Blackbears** blackbears;
      int tigerNum;
      int seaNum;
      int bearNum;
   public:
      Zoo();
      Zoo(int);
      ~Zoo(); 
      void newMonth();
      int playerturn();
      void payforfood();
      void randomevent();
      void calculateRevenue();
      void buyanimal();
      void sickanimal();
      void attendanceBoom();
      void newbabyborn();
      int getmoney();
      int gettigerSize();
      int getsealnSize();
      int getblackBSize();
      void setmoney(int);
      void settigerSize(int);
      void setsealnSize(int);
      void setblackbSize(int);
      
};
#endif