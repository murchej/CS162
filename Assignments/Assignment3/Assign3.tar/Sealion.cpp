/************************************************
 * Program Name: Zoo Tycoon
 * Author: Joseph Murche
 * Date: 2/2/21
 * Input:int
 * Output:strings,int
 * ***********************************************/

#include <string>
#include <cstdlib>
#include <iostream>
#include "animal.h"
#include "Sealion.h"

using namespace std;
 Sealions::Sealions() : Animal(){ //initializing member variables
     this->age = 1;
     this->cost = 800;
     this->numBabies = 1;
     this->baseFoodCost = 80;
     this->payoff = 160;
}

Sealions::Sealions(int x) : Animal(){ //constructor with params
    this->age = x;
    this->cost = 800;
    this->numBabies = 1;
    this->baseFoodCost = 80;
    this->payoff = 160;
}

int Sealions::getCost(){ //cost getter 
    return this->cost;
}

int Sealions::getAge(){ //age getter
    return age;
}

void Sealions::setAge(int x){ //age setter
    this->age = x;
}

void Sealions::setNumBabies(int x){ //num babies setter
    this-> numBabies = x;
}

int Sealions::getNumBabies(){ //num babies getter
    return numBabies;
}

int Sealions::getBaseFoodCost(){ //base food cost getter
    return this->baseFoodCost;
}

int Sealions::getPayoff(){ //payoff getter
    return this->payoff;
}