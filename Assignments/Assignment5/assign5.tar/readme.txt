Name: Joseph Murche

I have been using the c++11 friendly compiler, so you will wanna use that for this.
Other than that, I got nothing else to say! No extra credit was done.